// Copyright Epic Games, Inc. All Rights Reserved.

#include "Game_Jam.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Game_Jam, "Game_Jam" );
